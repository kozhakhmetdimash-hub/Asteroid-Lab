import asyncio
import pygame
import math
import random
import itertools

pygame.init()
WIDTH, HEIGHT = 900, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Asteroids")
clock = pygame.time.Clock()
V = pygame.math.Vector2

font = pygame.font.Font(None, 28)
btn_font = pygame.font.Font(None, 32)
mid_font = pygame.font.Font(None, 44)
big_font = pygame.font.Font(None, 96)
SHADE = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
SHADE.fill((0, 0, 0, 170))

WHITE, RED, YELLOW, GRAY = (255, 255, 255), (255, 60, 60), (255, 220, 0), (90, 90, 90)
ENEMY_MISSILE_COLOR = (255, 90, 90)

# ---- Player ship (Lesson 4): lower THRUST / MAX_SPEED = slower, easier ship ----
THRUST, DRAG, MAX_SPEED, ROTATION_SPEED, SHIP_RADIUS = 0.1, 0.99, 5, 3, 14

# ---- Enemy AI (Lesson 5) ----
DETECTION_RANGE = 300
FOV_THRESHOLD = 0.7
ENEMY_SCAN_SPEED = 0.5
ENEMY_FIRE_COOLDOWN = 70     # frames between shots
ENEMY_MISSILE_SPEED = 6      # slower than the player's missiles (9)
ENEMY_THRUST = 0.06          # chase acceleration
ENEMY_PATROL_THRUST = 0.02   # gentle creep while patrolling
ENEMY_DRAG = 0.98
ENEMY_MAX_SPEED = 2
ENEMY_RADIUS = 18

# ---- Asteroids: lower speeds = easier ----
ASTEROID_BASE_SPEED = 0.8
ASTEROID_WAVE_SPEED = 0.15   # extra speed per wave
ASTEROID_MAX_SPEED = 3.5
SPLIT_MIN_RADIUS = 22        # asteroids at least this big split when shot

# ---- Game rules ----
START_LIVES = 3
RESPAWN_INVULN, REVIVE_INVULN = 120, 180   # frames
WIN_WAVE = 5
SAFE_RADIUS = 110            # asteroids are cleared out of this zone when you respawn


# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------
def angle_to_vector(angle):
    r = math.radians(angle)
    return V(math.cos(r), -math.sin(r))   # minus: Pygame's y-axis points down


def wrap(pos):
    pos.x %= WIDTH
    pos.y %= HEIGHT


def random_spawn_pos(radius, avoid_pos, min_dist):
    """Random on-screen position at least min_dist away from avoid_pos."""
    for _ in range(200):
        pos = V(random.randint(radius, WIDTH - radius), random.randint(radius, HEIGHT - radius))
        if pos.distance_to(avoid_pos) >= min_dist:
            break
    return pos


def draw_text(msg, pos, text_font=font, color=WHITE, anchor="topleft"):
    surf = text_font.render(msg, True, color)
    screen.blit(surf, surf.get_rect(**{anchor: pos}))


def draw_lines(lines, x, y, anchor="topleft"):
    for i, line in enumerate(lines):
        draw_text(line, (x, y + 25 * i), anchor=anchor)


def draw_button(rect, label):
    hover = rect.collidepoint(pygame.mouse.get_pos())
    pygame.draw.rect(screen, (70, 130, 70) if hover else (40, 85, 40), rect, border_radius=8)
    pygame.draw.rect(screen, WHITE, rect, 2, border_radius=8)
    draw_text(label, rect.center, btn_font, anchor="center")


# ---------------------------------------------------------------------
# Asteroids
# ---------------------------------------------------------------------
class Asteroid:
    def __init__(self, radius=None, pos=None, vel=None, wave=1, avoid=None):
        self.radius = radius or random.randint(25, 40)
        self.mass = self.radius ** 2
        if pos is None:
            pos = random_spawn_pos(self.radius, avoid if avoid is not None else V(0, 0),
                                   160 if avoid is not None else 0)
        self.pos = V(pos)
        if vel is None:
            speed = ASTEROID_BASE_SPEED + ASTEROID_WAVE_SPEED * wave
            vel = V(random.uniform(-speed, speed), random.uniform(-speed, speed))
        self.vel = V(vel) if vel.length() else V(1, 1)
        if self.vel.length() > ASTEROID_MAX_SPEED:
            self.vel.scale_to_length(ASTEROID_MAX_SPEED)

    def update(self):
        self.pos += self.vel
        for axis, limit in ((0, WIDTH), (1, HEIGHT)):   # bounce off walls
            if self.pos[axis] - self.radius < 0:
                self.pos[axis], self.vel[axis] = self.radius, abs(self.vel[axis])
            elif self.pos[axis] + self.radius > limit:
                self.pos[axis], self.vel[axis] = limit - self.radius, -abs(self.vel[axis])

    def draw(self, surface):
        pygame.draw.circle(surface, (180, 180, 180), self.pos, self.radius)
        pygame.draw.circle(surface, WHITE, self.pos, self.radius, 2)

    def points(self):
        return max(30, int(150 - self.radius * 2))   # smaller = harder to hit = worth more

    def split(self):
        """Big asteroids break into two smaller, slightly faster ones."""
        if self.radius < SPLIT_MIN_RADIUS:
            return []
        r = int(self.radius * 0.6)
        kids = []
        for turn in (35, -35):
            vel = self.vel.rotate(turn) * 1.15
            kids.append(Asteroid(radius=r, pos=self.pos + vel.normalize() * r * 0.5, vel=vel))
        return kids


def handle_asteroid_collisions(asteroids):
    for a1, a2 in itertools.combinations(asteroids, 2):
        dist = a1.pos.distance_to(a2.pos)
        min_dist = a1.radius + a2.radius
        if dist >= min_dist or dist == 0:
            continue
        normal = (a1.pos - a2.pos).normalize()
        overlap = min_dist - dist
        a1.pos += normal * (overlap / 2)
        a2.pos -= normal * (overlap / 2)

        vel_normal = (a1.vel - a2.vel).dot(normal)
        if vel_normal < 0:
            impulse = -(1.0 + 0.9) * vel_normal / (1.0 / a1.mass + 1.0 / a2.mass)
            a1.vel += (impulse / a1.mass) * normal
            a2.vel -= (impulse / a2.mass) * normal


# ---------------------------------------------------------------------
# Missiles
# ---------------------------------------------------------------------
class Missile:
    LIFETIME = 90

    def __init__(self, pos, direction, speed=9, color=YELLOW):
        self.pos, self.vel, self.age, self.color = V(pos), direction * speed, 0, color

    def update(self):
        self.pos += self.vel
        self.age += 1

    def is_dead(self):
        return self.age > self.LIFETIME or not (0 <= self.pos.x <= WIDTH and 0 <= self.pos.y <= HEIGHT)

    def draw(self, surface):
        pygame.draw.circle(surface, self.color, self.pos, 5)
        pygame.draw.circle(surface, (0, 0, 0), self.pos, 5, 1)


def missiles_vs_asteroids(missiles, asteroids):
    """Missiles destroy (and split) asteroids. Returns (surviving_missiles, points)."""
    surviving, points = [], 0
    for m in missiles:
        hit = next((a for a in asteroids if m.pos.distance_to(a.pos) < a.radius), None)
        if hit is None:
            surviving.append(m)
        else:
            asteroids.remove(hit)
            asteroids.extend(hit.split())
            points += hit.points()
    return surviving, points


# ---------------------------------------------------------------------
# Craft: shared by the player ship and the enemy
# ---------------------------------------------------------------------
class Craft:
    def __init__(self, pos, angle=90):
        self.position, self.velocity, self.angle = V(pos), V(0, 0), angle

    def forward_vector(self):
        return angle_to_vector(self.angle)

    def move(self, drag, max_speed):
        """velocity *= drag, cap the speed, position += velocity, wrap the screen."""
        self.velocity *= drag
        if self.velocity.length() > max_speed:
            self.velocity.scale_to_length(max_speed)
        self.position += self.velocity
        wrap(self.position)

    def draw_shape(self, surface, forward, color=WHITE, fill=False):
        pts = [self.position + forward * 22,
               self.position + forward.rotate(140) * 16,
               self.position + forward.rotate(-140) * 16]
        if fill:
            pygame.draw.polygon(surface, color, pts)
        pygame.draw.polygon(surface, WHITE, pts, 2)


# ---------------------------------------------------------------------
# Player spaceship (Lesson 4: thrust, velocity, drag)
# ---------------------------------------------------------------------
class Spaceship(Craft):
    def __init__(self):
        super().__init__(V(0, 0))
        self.reset(0)

    def reset(self, invuln=RESPAWN_INVULN):
        self.position, self.velocity, self.angle = V(WIDTH / 2, HEIGHT / 2), V(0, 0), 90
        self.is_thrusting, self.invuln = False, invuln

    def update(self, keys):
        self.invuln = max(0, self.invuln - 1)
        self.angle += ROTATION_SPEED * (bool(keys[pygame.K_LEFT] or keys[pygame.K_a])
                                        - bool(keys[pygame.K_RIGHT] or keys[pygame.K_d]))
        self.is_thrusting = bool(keys[pygame.K_UP] or keys[pygame.K_w])
        if self.is_thrusting:
            self.velocity += self.forward_vector() * THRUST
        self.move(DRAG, MAX_SPEED)   # drag runs every frame -> slows down naturally

    def draw(self, surface, show_debug):
        if self.invuln > 0 and (self.invuln // 6) % 2 == 0:   # blink while invulnerable
            return
        forward = self.forward_vector()
        if self.is_thrusting:
            pygame.draw.circle(surface, YELLOW, self.position - forward * 18, 5)
        self.draw_shape(surface, forward)
        if show_debug:
            pygame.draw.line(surface, RED, self.position, self.position + forward * 60, 3)
            pygame.draw.line(surface, YELLOW, self.position, self.position + self.velocity * 10, 3)


# ---------------------------------------------------------------------
# Enemy (Lesson 5: distance + dot product field-of-view AI)
# ---------------------------------------------------------------------
class Enemy(Craft):
    def __init__(self, wave, avoid_pos):
        super().__init__(random_spawn_pos(ENEMY_RADIUS, avoid_pos, DETECTION_RANGE + 50),
                         random.randint(0, 359))
        self.max_hp = self.hp = 2 + wave
        self.alive, self.state = True, "PATROL"
        self.distance = self.dot = 0.0
        self.fire_timer = 0

    def update(self, player_pos):
        """Run the AI. Returns a Missile if the enemy fires this frame."""
        self.angle += ENEMY_SCAN_SPEED
        forward = self.forward_vector()

        to_player = player_pos - self.position
        self.distance = to_player.length()
        if self.distance > 0:
            to_player = to_player.normalize()
        self.dot = forward.dot(to_player)

        detected = self.distance < DETECTION_RANGE and self.dot > FOV_THRESHOLD
        self.state = "ATTACK" if detected else "PATROL"

        # chase when it sees you, otherwise creep along its (slowly rotating) forward vector
        self.velocity += to_player * ENEMY_THRUST if detected else forward * ENEMY_PATROL_THRUST
        self.move(ENEMY_DRAG, ENEMY_MAX_SPEED)

        self.fire_timer = max(0, self.fire_timer - 1)
        if detected and self.fire_timer == 0:
            self.fire_timer = ENEMY_FIRE_COOLDOWN
            return Missile(self.position, to_player, ENEMY_MISSILE_SPEED, ENEMY_MISSILE_COLOR)
        return None

    def take_hit(self):
        """Returns True if this hit destroyed the enemy."""
        self.hp -= 1
        self.alive = self.hp > 0
        return not self.alive

    def draw(self, surface, show_debug):
        forward = self.forward_vector()
        if show_debug:
            pygame.draw.circle(surface, GRAY, self.position, DETECTION_RANGE, 1)
            pygame.draw.line(surface, RED, self.position, self.position + forward * 100, 3)
        self.draw_shape(surface, forward, RED if self.state == "ATTACK" else WHITE, fill=True)

        bar = pygame.Rect(0, 0, 40, 5)   # health bar
        bar.center = (self.position.x, self.position.y - 34)
        pygame.draw.rect(surface, GRAY, bar)
        bar.width = int(40 * self.hp / self.max_hp)
        pygame.draw.rect(surface, RED, bar)


# ---------------------------------------------------------------------
# Game: state, rules, input, drawing
# ---------------------------------------------------------------------
BUTTONS = {   # state -> [(rect, label, Game method to call)]
    "GAME_OVER": [(pygame.Rect(WIDTH // 2 - 175, 360, 160, 50), "REVIVE (V)", "revive"),
                  (pygame.Rect(WIDTH // 2 + 15, 360, 160, 50), "RESTART (R)", "reset")],
    "WIN": [(pygame.Rect(WIDTH // 2 - 80, 360, 160, 50), "PLAY AGAIN (R)", "reset")],
}
KEY_ACTIONS = {
    "GAME_OVER": {pygame.K_v: "revive", pygame.K_r: "reset"},
    "WIN": {pygame.K_r: "reset"},
}


class Game:
    def __init__(self):
        self.show_debug = True
        self.reset()

    def reset(self):
        """Full restart."""
        self.score, self.lives, self.wave, self.state = 0, START_LIVES, 1, "PLAYING"
        self.ship = Spaceship()
        self.missiles = []
        self.start_wave()

    def start_wave(self):
        self.asteroids = [Asteroid(wave=self.wave, avoid=self.ship.position) for _ in range(3 + self.wave)]
        self.enemy = Enemy(self.wave, self.ship.position)
        self.enemy_missiles = []
        self.banner_timer = 120

    def respawn(self, invuln):
        """Ship back to center; asteroids and enemy missiles cleared out of its way."""
        self.ship.reset(invuln)
        self.enemy_missiles = []
        center = self.ship.position
        for ast in self.asteroids:
            if ast.pos.distance_to(center) < SAFE_RADIUS + ast.radius:
                ast.pos = random_spawn_pos(ast.radius, center, SAFE_RADIUS + ast.radius + 20)

    def revive(self):
        """Back from GAME OVER: lives refilled, score and wave kept."""
        self.lives, self.state = START_LIVES, "PLAYING"
        self.respawn(REVIVE_INVULN)

    def hurt_player(self):
        self.lives -= 1
        if self.lives <= 0:
            self.state = "GAME_OVER"
        else:
            self.respawn(RESPAWN_INVULN)

    def handle_event(self, event):
        action = None
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_h:
                self.show_debug = not self.show_debug
            elif self.state == "PLAYING" and event.key == pygame.K_SPACE:
                forward = self.ship.forward_vector()
                self.missiles.append(Missile(self.ship.position + forward * 22, forward))
            action = KEY_ACTIONS.get(self.state, {}).get(event.key)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            action = next((a for rect, _, a in BUTTONS.get(self.state, [])
                           if rect.collidepoint(event.pos)), None)
        if action:
            getattr(self, action)()

    def update(self, keys):
        if self.state != "PLAYING":
            return
        ship, enemy = self.ship, self.enemy
        self.banner_timer = max(0, self.banner_timer - 1)

        ship.update(keys)
        if enemy.alive:
            shot = enemy.update(ship.position)
            if shot:
                self.enemy_missiles.append(shot)

        for ast in self.asteroids:
            ast.update()
        handle_asteroid_collisions(self.asteroids)

        for m in self.missiles + self.enemy_missiles:
            m.update()
        self.missiles = [m for m in self.missiles if not m.is_dead()]
        self.enemy_missiles = [m for m in self.enemy_missiles if not m.is_dead()]

        # only the player's missiles score points
        self.missiles, points = missiles_vs_asteroids(self.missiles, self.asteroids)
        self.score += points
        self.enemy_missiles, _ = missiles_vs_asteroids(self.enemy_missiles, self.asteroids)

        for m in list(self.missiles):   # player missiles vs enemy
            if enemy.alive and m.pos.distance_to(enemy.position) < ENEMY_RADIUS:
                self.missiles.remove(m)
                self.score += 50 + (500 if enemy.take_hit() else 0)

        self.check_player_hit()

        if self.state == "PLAYING" and not self.asteroids and not enemy.alive:   # wave cleared
            self.score += 250
            if self.wave >= WIN_WAVE:
                self.state = "WIN"
            else:
                self.wave += 1
                self.start_wave()

    def check_player_hit(self):
        ship = self.ship
        if ship.invuln > 0:
            return
        missile = next((m for m in self.enemy_missiles
                        if ship.position.distance_to(m.pos) < SHIP_RADIUS + 4), None)
        if missile:
            self.enemy_missiles.remove(missile)
        rammed = self.enemy.alive and ship.position.distance_to(self.enemy.position) < SHIP_RADIUS + ENEMY_RADIUS
        crashed = any(ship.position.distance_to(a.pos) < a.radius + SHIP_RADIUS for a in self.asteroids)
        if missile or rammed or crashed:
            self.hurt_player()

    def draw(self):
        screen.fill((10, 10, 30))
        for obj in (*self.asteroids, *self.missiles, *self.enemy_missiles):
            obj.draw(screen)
        if self.enemy.alive:
            self.enemy.draw(screen, self.show_debug)
        if self.state != "GAME_OVER":
            self.ship.draw(screen, self.show_debug)

        draw_lines((f"Score: {self.score}", f"Lives: {self.lives}", f"Wave: {self.wave}/{WIN_WAVE}"),
                   WIDTH - 10, 10, anchor="topright")

        if self.show_debug:   # lesson readouts - toggle with H
            ship, e = self.ship, self.enemy
            draw_lines((f"Angle: {ship.angle % 360:.0f}", f"Speed: {ship.velocity.length():.2f}",
                        f"Velocity: ({ship.velocity.x:.2f}, {ship.velocity.y:.2f})"), 10, 10)
            if e.alive:
                draw_lines((f"Distance: {e.distance:.1f}", f"Dot Product: {e.dot:.2f}"), 10, 95)
                draw_text(f"Enemy State: {e.state}", (10, 145), color=RED if e.state == "ATTACK" else WHITE)

        draw_text("Arrows/WASD: fly   SPACE: fire   H: toggle debug", (10, HEIGHT - 28), color=GRAY)
        if self.banner_timer and self.state == "PLAYING":
            draw_text(f"WAVE {self.wave}", (WIDTH // 2, 90), mid_font, YELLOW, "center")

        if self.state in BUTTONS:   # GAME_OVER / WIN overlay
            over = self.state == "GAME_OVER"
            screen.blit(SHADE, (0, 0))
            draw_text("GAME OVER" if over else "YOU WIN!", (WIDTH // 2, 220), big_font,
                      RED if over else YELLOW, "center")
            draw_text(f"Score: {self.score}   Wave: {self.wave}" if over else f"Final score: {self.score}",
                      (WIDTH // 2, 290), mid_font, anchor="center")
            for rect, label, _ in BUTTONS[self.state]:
                draw_button(rect, label)


async def main():
    game = Game()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            else:
                game.handle_event(event)
        game.update(pygame.key.get_pressed())
        game.draw()
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)   # lets the browser breathe (required for pygbag)
    pygame.quit()


asyncio.run(main())
